$(document).ready(init);
$('.upvote').upvote();

function init() {
  var upVotes = $(".upvote.upvote")
  var downVotes = $(".upvote.downvote")

   for(var i=0; i < upVotes.length; i+=1) {
      upVotes[i].addEventListener("click", upVote)
   };
   for(var i=0; i < downVotes.length; i+=1) {
      downVotes[i].addEventListener("click", downVote)
   };
};

function upVote() {
  var path = this.getAttribute("data-path");
  var request = $.ajax({
    method: "post",
    url: path 
  });
}

function downVote() {
  var path = this.getAttribute("data-path");
  var request = $.ajax({
    method: "post",
    url: path 
  });
}
